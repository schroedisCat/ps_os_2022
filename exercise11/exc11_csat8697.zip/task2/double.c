int method(int x) {
    return (x * 2);
}