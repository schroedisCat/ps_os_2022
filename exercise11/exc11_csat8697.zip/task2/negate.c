int method(int x) {
    return (-x);
}